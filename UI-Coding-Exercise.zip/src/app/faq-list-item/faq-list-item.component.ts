import { Component, Input } from '@angular/core';
import { FAQ } from '../models/faq.model';

@Component({
  selector: 'app-faq-list-item',
  templateUrl: './faq-list-item.component.html',
  styleUrls: ['./faq-list-item.component.scss']
})
export class FaqListItemComponent {
  collapseToggle = false;
  @Input() faq: FAQ;

  constructor() { }

  onCollapseToggle() {
    this.collapseToggle = !this.collapseToggle;
  }
}
