import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FaqListItemComponent } from './faq-list-item.component';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { FAQ } from '../models/faq.model';

describe('FaqListItemComponent', () => {
  let component: FaqListItemComponent;
  let fixture: ComponentFixture<FaqListItemComponent>;
  let faqItemEL: DebugElement;
  let testFAQ: FAQ;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FaqListItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FaqListItemComponent);
    component = fixture.componentInstance;

    // test faq
    testFAQ = {
      id: '1',
      question: 'my test question',
      answer: 'my test answer'
    };

    // add test faq to component
    component.faq = testFAQ;

    // trigger layout changes
    fixture.detectChanges();

    // console.log(fixture.debugElement);
    faqItemEL = fixture.debugElement;
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('collapseToggle value to change when onCollapseToggle() called', () => {

    // initial state: false
    expect(component.collapseToggle).toBeFalse();

    // flip to true
    component.onCollapseToggle();
    expect(component.collapseToggle).toBeTrue();

    // flip to false
    component.onCollapseToggle();
    expect(component.collapseToggle).toBeFalse();
  });

  it('when selected the faq-item should have the selected class', () => {

    // initial state: faq item should now be unselected
    let faqItem = faqItemEL.query(By.css('.faq-item.selected'));
    expect(faqItem).toBeFalsy();

    // selected item
    component.onCollapseToggle();
    fixture.detectChanges();

    // faq item should now be selected
    faqItem = faqItemEL.query(By.css('.faq-item.selected'));
    expect(faqItem).toBeTruthy();

    // unselected item
    component.onCollapseToggle();
    fixture.detectChanges();

    // faq item should now be unselected
    faqItem = faqItemEL.query(By.css('.faq-item.selected'));
    expect(faqItem).toBeFalsy();
  });

  it('values inside the component should equal the test FAQ values', () => {
    const faqHeaderID = faqItemEL.query(By.css('.faq-item .faq-header span:first-child'));
    const faqHeaderQuestion = faqItemEL.query(By.css('.faq-item .faq-header'));
    const faqHeaderAnswer = faqItemEL.query(By.css('.faq-item .faq-body'));

    // check component values against test FAQ
    expect(faqHeaderID.nativeElement.innerText).toBe(('q' + testFAQ.id).toUpperCase());
    expect(faqHeaderQuestion.nativeElement.innerText).toContain(testFAQ.question);
    expect(faqHeaderAnswer.nativeElement.innerText).toBe(testFAQ.answer);
  });

  xit('svg icon to be rotated when faq item is selected', () => {
    // NB: not run as can't retreive the transform value

    // initial state: svg rotate = 0deg
    let faqSvg = faqItemEL.query(By.css('.faq-item .faq-header span:last-child svg'));
    // console.log(faqSvg.nativeElement.style.transform);
    expect(faqSvg.nativeElement.style.transform).toBeFalsy();

    // selected item
    component.onCollapseToggle();
    fixture.detectChanges();

    // svg rotate should now be 45deg
    faqSvg = faqItemEL.query(By.css('.faq-item.selected .faq-header span:last-child svg'));
    // console.log(faqSvg);
    expect(faqSvg.nativeElement.style.transform).toBeTruthy();
  });
});


