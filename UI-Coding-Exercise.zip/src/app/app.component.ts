import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FAQ } from './models/faq.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  faqs: FAQ[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get<FAQ[]>('./assets/data/faqs.json').subscribe(
    (res) => {
      this.faqs = res;
    },
    (err) => {
      console.log('Someone moved the file!. Check assets/data/faqs.json exists.');
    });
  }
}
