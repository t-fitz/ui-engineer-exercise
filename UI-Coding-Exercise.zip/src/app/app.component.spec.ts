import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { By } from '@angular/platform-browser';
import { FaqListItemComponent } from './faq-list-item/faq-list-item.component';

describe('AppComponent', () => {
  let fixture: ComponentFixture<AppComponent>;
  let app: AppComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        FaqListItemComponent
      ],
      imports: [
        HttpClientModule
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(AppComponent);
    app = fixture.componentInstance;
  }));

  it('should create the app', () => {
    expect(app).toBeTruthy();
  });

  it('should retrieve the json data', async(() => {
    app.ngOnInit();

    fixture.detectChanges();

    fixture.whenStable().then(() => {
      // console.log(app.faqs);
      expect(app.faqs.length).toBeGreaterThan(0);
    });
  }));

  it ('faq-list-item components should be created', () => {
    const faqJson = {
      id: '1',
      question: 'test question',
      answer: 'test answer'
    };

    app.faqs = [faqJson];

    fixture.detectChanges();

    const faqItemEL = fixture.debugElement;
    const faqHeaderID = faqItemEL.query(By.css('.faq-item .faq-header span:first-child'));
    const faqHeaderQuestion = faqItemEL.query(By.css('.faq-item .faq-header'));
    const faqHeaderAnswer = faqItemEL.query(By.css('.faq-item .faq-body'));

    // check component values against test FAQ
    expect(faqHeaderID.nativeElement.innerText).toBe(('q' + faqJson.id).toUpperCase());
    expect(faqHeaderQuestion.nativeElement.innerText).toContain(faqJson.question);
    expect(faqHeaderAnswer.nativeElement.innerText).toBe(faqJson.answer);
  });
});
